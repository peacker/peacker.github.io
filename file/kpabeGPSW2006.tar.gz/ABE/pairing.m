/*
TYPE A CURVES
-------------
REF: "On the implementation of pairing-based cryptosystems", 
     Lynn PhD Thesis, p. 64

* q = 3 mod 4
* E : Y^2 = x^3 + ax, a in F_q
* E is supersingular
* #E(F_q)   = q + 1
  #E(F_q^2) = (q + 1)^2
* For any r s.t. r | q + 1 we have
  G = E(F_q)[r] is cyclic and has embedding degree k = 2
* We have -1 is quadratic nonresidue in F_q, since q = 3 mod 4
  Then if i = SQRT(-1), we have the distorsion map
  phi( (x,y) ) = ( -x , iy )
  which maps points of E(F_q) to point of E(F_q^2)\E(F_q)
* Thus if f denotes the Weil pairing, we can obtain a
  bilinear nondegenerate map:
  e : G x G -> F_q^2
  e(P,Q) = f(P,phi(Q))
  Note that the Weil pairing f is s.t.
  f : E(F_q^2)[r] x E(F_q^2)[r] -> F_q^2 

*/

//---------------------------------------------

// GLOBAL VARIABLES
// ----------------
K := GF(59) ;
E := EllipticCurve( [ K | 1, 0 ] ) ; 
K2<z> := ExtensionField< K , x | x^2+1 > ;
E2 := ChangeRing(E,K2) ;
P := E![25,29,1] ; 
r := Order(P) ;

// TO CHOOSE GLOBAL VARIABLES (they must be defined before phi() and e() )
// --------------------------
// choose a good elliptic curve E(F_q) with embedding degree 2 
// and equation
// E : Y^2 = x^3 + ax, a in F_q
// such that
// - F_q^2 resists Index Calcolus attacks,
//   i.e., q ~ 1024 bit
// - #E is divisible by a prime r such of 160 bit,
//   to avoid general Discrete Log attacks
// Note that #E(F_q) = hr must be of 512 bits, so that q^2 is 1024
// thus h is 512 - 160 = 362 bits
// Choose h to be a multiple of 4 (why???)

q_square_size := 256 ; // field F_q^2 size // should be at least 1024
r_size := 40 ; // group G size // should be at least 160
h_size := (q_square_size div 2) - r_size ;


SearchTypeASupersingularCurve := function( q_square_size, r_size, a : verb := true)
local q, r, h, E, F, P ;
local found ;
  // find q = 3 mod 4
  q := NextPrime(2^(q_square_size div 2)) ;
  while (q mod 4) ne 3 do
    q := NextPrime(q) ;
  end while ;

  a := 1 ;
  found := 0 ;
  while found eq 0 do
  //  if (a mod 1000) eq 0 then a ; end if ;
    r := 0 ;
    h := 0 ;
    E := EllipticCurve( [ GF(q) | a , 0 ] ) ;
    F := Factorization(#E) ;
    for i in [1..#F] do
  //Floor(Log(2,F[i][1])) ;
      if Floor(Log(2,F[i][1])) eq r_size-1 then
         //Floor(Log(2,F[i][1])) le r_size+4 and  
         //Floor(Log(2,F[i][1])) ge r_size-4 then
        r := F[i][1] ;
        h := #E div r ;

      end if ;
    end for ; 

    if (r ne 0) and ((h mod 4) eq 0) then
      found := 1 ;
    else 
      //a := a + 1 ;
      repeat
        q := NextPrime(q) ;
      until (q mod 4) eq 3 ;
    end if ;

  end while ;
  
  if verb then
  "found E", E ;
  "searching for point P of order", r ;
  end if ;
   
  // FIND P of order r
  repeat
    P := Random(E) ;
    if (Order(P) mod r) eq 0 then
      P := (Order(P) div r)*P ;
    end if ;
  until Order(P) eq r ;
  
  return r, P ;
end function ;

r, P := SearchTypeASupersingularCurve(256,40,1) ;
K := Parent(P[1]) ;
E := Scheme(P) ;
K2<z> := ExtensionField< K , x | x^2+1 > ;
E2 := ChangeRing(E,K2) ;

//---------------------------------------------

phi := function( P )
// DISTORSION MAP
// Given a point of E(F_q^2) with coordinates in F_q
// returns a point of E(F_q^2)
// phi( (x,y) ) = ( -x , iy ), where i is the square root of -1
// which is not a nonsquare if q = 3 mod 4
// E must be E(F_q^2)
//

  if P eq E2![0,1,0] then
    return E2![ K2!(-P[1]), K2.1*P[2] , 0] ;
  else
    return E2![ K2!(-P[1]), K2.1*P[2] , 1] ;
  end if ;
end function ;

//---------------------------------------------

e := function ( P , Q )
// BILINEAR SYMMETRIC PAIRING
// When the underlying field is F_q s.t. q = 3 mod 4 
// e : G x G -> F_q^2
// e : (U,V) -> WeilPairing( U , phi(V) )
// G subset of E(F_q) of prime order r

  return K2!WeilPairing( E2!P, phi(E2!Q), r ) ;
end function ;

//---------------------------------------------

// check properties of the bilinear map
Q := Random(r)*P ;
// SYMMETRY
e(P,Q) eq e(Q,P) ;
// NONDEGENERACY
e(P,P) ne 1 ;
// BILINEARITY
e(2*P,3*Q) eq e(Q,P)^(2*3) ;
// NEUTRAL ELEMENT
O := E![0,1,0] ;
e(O,O) eq 1 ;
e(O,P) eq 1 ;
e(P,O) eq 1 ;


