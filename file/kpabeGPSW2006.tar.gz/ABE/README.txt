Work done by Emanuele Bellini
Last test: 2016-02-12

//----------------------------------------------------------------------------

To use the examples:

- open MAGMA from within the folder ABE

- type
  laod "kpabe_ex1.m" ;
  or
  laod "kpabe_ex2.m" ;

//----------------------------------------------------------------------------

In each file it is possible either

1 - to define the ABE parameters explicitly
    (i.e., the group G_1, G_2, the elliptic curve, the pairing, etc.)

or 

2 - to find one set of parameters each time using the file
    "pairing.m"


For option 1 

* uncomment the lines defining the GLOBAL VARIABLES and

* comment the line
  load "pairing.m" ;

in the files
"kpabe_ex1.m"
"kpabe_ex2.m"


For option 2 do viceversa...
