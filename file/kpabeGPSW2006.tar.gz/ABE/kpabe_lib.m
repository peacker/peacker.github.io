//////////////////////////////////////////////////////////////////////////////
// Work done by Emanuele Bellini,                                           //
// Telsy S.p.A.                                                             //
//                                                            Torino, 2015  //
//////////////////////////////////////////////////////////////////////////////

// clear ;
/*
REF: "Attribute-based Encryption for Fine-Grained Access Control of Encrypted Data"
     Goyal, Pandey, Sahai, Waters, 2006
     Section 4.2 


NOTATION:
---------
  G_1 <--> <P>
  g   <--> P
  G_2 <--> F_q^2
  p   <--> r

*/

// UNCOMMENT IF GLOBAL VARIABLES MUST BE INCLUDED!!
/*
// GLOBAL VARIABLES
// ----------------

K := GF(340282366920938463463374607431768216923) ;
E := EllipticCurve( [ K | 1, 0 ] ) ; 
K2<z> := ExtensionField< K , x | x^2+1 > ;
E2 := ChangeRing(E,K2) ;
P := E![199271605215943908268709599389110266979,225490490528012404940003766658466280865,1] ; 
r := Order(P) ;

ATTRIBUTES := [
              "Stagione1",
              "Stagione2",
              "Stagione3",
              "Stagione4",
              "Stagione5",
              "Episodio1",
              "Episodio2",
              "Episodio3",
              "Episodio4",
              "Episodio5",
              "Episodio6",
              "Episodio7",
              "Episodio8",
              "Episodio9",
              "Episodio10",
              "Serie1",
              "Serie2",
              "Serie3"
              ] ;

n := #ATTRIBUTES ; // number of attributes
U := [i : i in [1..n]] ; // Universe of attributes
*/

//---------------------------------------------
//---------------------------------------------

// DISTORSION MAP
// --------------
phi := function( P )
// Given a point of E(F_q^2) with coordinates in F_q
// returns a point of E(F_q^2)
// phi( (x,y) ) = ( -x , iy ), where i is the square root of -1
// which is not a nonsquare if q = 3 mod 4
// E must be E(F_q^2)
//

  if P eq E2![0,1,0] then
    return E2![ K2!(-P[1]), K2.1*P[2] , 0] ;
  else
    return E2![ K2!(-P[1]), K2.1*P[2] , 1] ;
  end if ;
end function ;

//---------------------------------------------

// BILINEAR SYMMETRIC PAIRING
// --------------------------
e := function ( P , Q )
// When the underlying field is F_q s.t. q = 3 mod 4 
// e : G x G -> F_q^2
// e : (U,V) -> WeilPairing( U , phi(V) )
// G subset of E(F_q) of prime order r

  return K2!WeilPairing( E2!P, phi(E2!Q), r ) ;
end function ;

//---------------------------------------------

// ACCESS TREE
// -----------
// x is the name of the node (a number)
// m is the number of nodes
// k is the threshold of a node
//   is 0 if leaf node
// num_children is the number of children of a node
//   is 0 if leaf node
// father is the number of the parent node
//   is 0 if root node
// index is the number identifying the node between his brothers
//   is 0 if root node
// att is the attribute associated to a leaf node 
//   is 0 if not leaf node
//
// TREE := [
// x[0], k[0], num_children[0], father[0], index[0], att[0],
// x[1], k[1], num_children[1], father[1], index[0], att[1],
// x[2], k[2], num_children[2], father[2], index[0], att[2],
// ...
// x[m], k[m], num_children[m], father[m], index[0], att[m]
// ] ;
//
// EXAMPLE:
// U = {1,2,3,4,5,6,7,8,9,10}
// the policy
// or( and(1,2,5), and(2,3) )
// can be represented as
/*
TREE :=  [// or( and(1,2,5), and(2,3) )
         [ 1, 1, 2, 0, 0, 0 ],        //-> root node or
         [ 2, 3, 3, 1, 1, 0 ],        //-> node and
         [ 3, 2, 2, 1, 2, 0 ],        //-> node and
         [ 4, 0, 0, 2, 1, 1 ],       //-> leaf node att(4) = 1
         [ 5, 0, 0, 2, 2, 2 ],       //-> leaf node att(5) = 2
         [ 6, 0, 0, 2, 3, 5 ],       //-> leaf node att(6) = 5
         [ 7, 0, 0, 3, 1, 2 ],       //-> leaf node att(7) = 2
         [ 8, 0, 0, 3, 2, 3 ]        //-> leaf node att(8) = 3
         ] ;
*/
// NOTE: it is important to insert first rows representing older generations
//

Threshold := function(x, TREE)
  return TREE[x][2] ;
end function ;

NumberOfChildren := function(x, TREE)
  return TREE[x][3] ;
end function ;

Father := function(x, TREE)
  return TREE[x][4] ;
end function ;

Index := function(x, TREE)
  return TREE[x][5] ;
end function ;

Attribute := function(x, TREE)
  return TREE[x][6] ;
end function ;

SatisfyTREE := function( GAMMA, TREE)
// ...
local flag ;

  return flag ;
end function ;

//---------------------------------------------

NumberOfChar := function ( s , c )
local pos ; // list of positions
  pos := [] ;
  for i in [1 .. #s] do
    if s[i] eq c then
      pos := pos cat [i] ;
    end if ;
  end for ;

  return #pos, pos ;
end function ;

SplitString := function( str )
local ss ;
local SS ; // vector of substrings
local i, j ;
local open, close ;

  if NumberOfChar( str , ",") eq 0 then
    return [] ;
  end if ;

  i := 1 ;
  repeat
    i := i + 1 ;
  until str[i] eq "(" ;
  ss := Substring( str , i+1 , #str-i-1 ) ;

    i := 1 ;
    SS := [] ;
    j := 1 ;
    while i le #ss do
      SS[j] := "" ;
      while ss[i] ne "(" do
        SS[j] := SS[j] cat ss[i] ;
        i := i + 1 ;
      end while ;
      open := 0 ;
      close := 0 ;
      repeat
        if ss[i] eq "(" then
          open := open + 1 ;
        elif ss[i] eq ")" then
          close := close + 1 ;
        end if ;
        SS[j] := SS[j] cat ss[i] ;
        i := i + 1 ;
      until open eq close ;
      j := j + 1 ;
      i := i + 1 ;
    end while ;

  return SS ;
end function ;

CreateNODE := procedure( str , father , ind , ~TREE )
// s is the string
// father is the father from which the node is called
// ind i
local SS ; // list of sub trees
local th ; // threshold
local j ;
local fa ;

  SS := SplitString(str) ;
  
  // LEAF NODE CASE
  if SS eq [] then 
    TREE[#TREE+1] := [ #TREE + 1 , 0 , 0 , father , ind , StringToInteger(Substring(str,2,#str-2)) ] ;
  // NON-LEAF NODE CASE
  else
    // find threshold
    j := 2 ;
    th := "" ;
    while str[j] ne "(" do
      th := th cat str[j] ;
      j := j + 1 ;
    end while ;
    // create new node
    TREE[#TREE+1] := [ #TREE + 1 , StringToInteger(th) , #SS , father , ind , 0 ] ;
    // recursive call
    fa := #TREE ;
    for i in [1..#SS] do
      $$( SS[i] , fa , i , ~TREE) ;
    end for ;
  end if ;

end procedure ;

CreateTREE := function( str ) 
// s is a policy
// s := ">2(>3((1),(2),(3)),>1((6),(7)))" ;
// stands for and(and(1,2,3),or(6,7))
//
local TREE ;

  TREE := [] ;
  CreateNODE( str , 0 , 0 , ~TREE) ;

  return TREE ;
end function ;

Replace := function ( s1 , s2 , str)
// in string str
// whenever s1 appears insert s2
local temp ;
local i ;

  temp := str ;
  i := 1 ;
  while i le #temp-#s1+1 do
    if s1 eq temp[i..i+#s1-1] then
      temp := temp[1..i-1] cat s2 cat temp[i+#s1..#temp] ;
      i := i + #s2 ;
    else
      i := i + 1 ;
    end if ;
  end while ;

  return temp ;
end function ;

ConvertPOLICY := function( str , attr )
local i ;
local temp ;

  temp := str ;
  i := 1 ;
  for a in attr do
    temp := Replace( a , "(" cat IntegerToString(i) cat ")", temp ) ;
    i := i + 1 ;
  end for ;

  return temp ;
end function ;

POLICY2TREE := function( pol , attr )
local tree ;
local pol_encoded ;  

  pol_encoded := ConvertPOLICY( pol , attr ) ;
  tree := CreateTREE( pol_encoded ) ;

  return tree ;
end function ;

//---------------------------------------------

// INTERPOLATION
// -------------

delta := function( i , S )

local R ;

  R<x> := PolynomialRing(Integers(r)) ;
  
  if (S diff {i}) eq {} then
    return R!1 ;
  end if ;

  return &*[(x-j)/(i-j) : j in S | j ne i] ;
end function ;

//---------------------------------------------

// MAIN FUNCTIONS
// --------------

//---------------------------------------------

Setup := function( U )
//
local t ; 
local T ;
local y ;
local Y ;
local PK ;
local MK ;

  t := [] ;
  for i in U do 
    t[i] := Random(r) ;
  end for ;
  T := [t[i]*P : i in U] ;
  y := Random(r) ;
  Y := e(P,P)^y ;

  PK := [* T , Y *];
  MK := [* t , y *];

  return PK, MK ;
end function ;

//---------------------------------------------

Encryption := function( M , GAMMA , PK )
// INPUT:
// - M     is an element of G_2 = F_q^2
// - GAMMA is a set of attributes (subset of U)
// - PK    is the public key
local c_ ; // encrypted message
local C ; // attribute encrypted information
local s ;
local Y ; 
local c ; // entire ciphertext
local T ;

  s := Random(r) ;
  Y := PK[2] ;
  cc := M*(Y^s) ;

  T := PK[1] ;

  C_ := [] ;
  for i in [1..#T] do // #T is the number of elements in the universe U
    if i in GAMMA then
      C_[i] := s*T[i] ;
    end if ;
  end for ;

  c := [* GAMMA , cc , C_ *] ;

  // return c, s ;
  return c ;
end function ;

//---------------------------------------------

KeyGeneration := function( TREE , MK )
//
local R ; // polynomials ring
local q ; // list of polynomials associated to a node
local D_ ; // list of decryption keys
local t ;

  t := MK[1] ;
  // R<x> := PolynomialRing(K) ;
  // R<x> := PolynomialRing(Integers()) ;
  R<x> := PolynomialRing(Integers(r)) ;
  q := [] ;
  D_ := [] ;
  for i in [1..#TREE] do
    // CREATE POLYNOMIALS
    if Father(i,TREE) eq 0 then // ROOT NODE CASE
      q[i] := R!MK[#MK] ; // q_r(0) = y defined the constant term
      for j in [1..Threshold(i,TREE) - 1] do // define randomly other terms
        //q[i] := q[i] + x^j * Random(K) ;
        q[i] := q[i] + x^j * Random(r) ;
      end for ;
    else // NON-ROOT NODE CASE
      q[i] := Evaluate(q[Father(i,TREE)], Index(i,TREE) );
      for j in [1..Threshold(i,TREE) - 1] do // define randomly other terms
        // q[i] := q[i] + x^j * Random(K) ;
        q[i] := q[i] + x^j * Random(r) ;
      end for ;
    end if ;

    // CREATE DECRYPTION KEY
    if Attribute(i,TREE) ne 0 then // LEAF NODE CASE
      D_[i] := Integers()!(Evaluate(q[i], 0 )/t[Attribute(i,TREE)]) * P ;
    end if ;
 
  end for ;

  // return [* TREE, D_ *], q ;
  // return D ;
  return [* TREE, D_ *] ;
end function ;

//---------------------------------------------

STOP := function()
  return K2!0 ;
end function ;

DecryptNode := function( c , D , x : verb := false)
// [* GAMMA , cc , C_ *] 
// D = [* TREE, D_ *]
// x is the number identifying the node
local TREE ;
local GAMMA ;
local i ;
local F ; // list of outputs of the children
local Sx ;
local Sx_ ;
local temp ;
local Fx ;

  if verb then  "---------" ;  "NODO = ", x ;  end if ;

  TREE := D[1] ;
  i := Attribute(x,TREE) ;

  // LEAF NODE CASE
  if i ne 0 then 
    if i in c[1] then
      Fx := K2!e( D[2][x] , c[3][i] ) ;
      if verb then printf "F[%o] = %o\n", x, Fx ; printf "i = %o\n", i ; end if ;
      return Fx ;
    else
      if verb then "ALT" ; end if ;
      return STOP() ; // STOP SIGNAL
    end if ;

  // NON-LEAF NODE CASE
  else 
    F := [ STOP() : j in [1..NumberOfChildren(x,TREE)] ] ;
    for z in [1..#TREE] do
      // recursive call for all children of x
      if TREE[z][4] eq x then
        temp := $$( c , D , z) ;
        F[z] := temp ;
      else
        F[z] := K2!0 ;
      end if ;
    end for ;

    // CREATE Sx and Sx'
    Sx := [] ;
    for z in [1..#F] do
      if ( not IsZero(F[z])/*F[z] ne Zero(Parent(F[z]))*/)  and (#Sx lt TREE[x][2]) then
        Sx := Sx cat [z] ;
      end if ;
    end for ;    
    Sx_ := {Index(z,TREE) : z in Sx} ;
    if verb then "Sx  = " , Sx ; "Sx' = " , Sx_ ; "Threshold = ", TREE[x][2] ; end if ;

    // COMPUTE Fx = &*[Fz^delta_{i,Sx'}(x) : z in Sx] 
    if #Sx_ ge TREE[x][2] then
      Fx := 1 ;
      for z in Sx do
        temp := delta(Index(z,TREE),Sx_) ;
        Fx := Fx * F[z]^Integers()!Evaluate(temp,0) ;
      end for ;
      if verb then printf "F[%o] = %o\n", x, Fx ; end if ;

      return Fx ;
    else 
      if verb then "ALT" ; end if ;

      return STOP() ;
    end if ;

  end if ;

end function ;

Decryption := function( c , D )
// [* GAMMA , cc , C_ *] 
// D = [* TREE, D_ *]
local Ys ;
  
  Ys := DecryptNode( c , D , 1) ;
  
  if Ys eq 0 then
    "ERROR! Decryption NOT ALLOWED!" ;
    return 0 ;
  end if ;

  return c[2]/Ys ;
end function ;

//---------------------------------------------
//---------------------------------------------

