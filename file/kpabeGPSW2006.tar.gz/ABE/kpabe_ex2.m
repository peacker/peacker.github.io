clear ;
/*
REF: "Attribute-based Encryption for Fine-Grained Access Control of Encrypted Data"
     Goyal, Pandey, Sahai, Waters
     Section 4.2 


NOTATION:
---------
  G_1 <--> <P>
  g   <--> P
  G_2 <--> F_q^2
  p   <--> r

*/

//////////////////////////////////////////////////////////////////////////////

// GLOBAL VARIABLES
// ----------------


// to generate a new curve uncomment the following line
load "pairing.m" ;

// to use known global parameter uncomment the following  lines

/*
K := GF(340282366920938463463374607431768216923) ;
E := EllipticCurve( [ K | 1, 0 ] ) ; 
K2<z> := ExtensionField< K , x | x^2+1 > ;
E2 := ChangeRing(E,K2) ;
P := E![199271605215943908268709599389110266979,225490490528012404940003766658466280865,1] ; 
r := Order(P) ;
*/

//////////////////////////////////////////////////////////////////////////////
// ATTENTION: 
// Library must be loaded after global variables are set.
load "kpabe_lib.m" ;


ATTRIBUTES := [
              "MARINA",    // 1
              "AVIAZIONE", // 2
              "TERRA",     // 3
              "Plotone1",  // 4
              "Plotone2",  // 5
              "Plotone3",  // 6
              "Plotone4",  // 7
              "Missione1", // 8
              "Missione2", // 9
              "Missione3"  // 10
              ] ;

n := #ATTRIBUTES ; // number of attributes
U := [i : i in [1..n]] ; // Universe of attributes

// We send many groups in Mission1, but
// only the following groups should be able do receive messages:
// 1) MARINA, Plotone1 and Plotone 2
// 2) AVIAZIONE, Plotone1
// 3) AVIAZIONE, Plotone3 
// We must distribute keys, such that
// each of the above group can decrypt

POLICY := [] ;
POLICY[1] := ">1(>2(MARINA,Plotone1),>2(MARINA,Plotone2))" ; // attributes 1 , 4 , 5
POLICY[2] := ">2(AVIAZIONE,Plotone1)" ; // attributes 2 , 4 
POLICY[3] := ">2(AVIAZIONE,Plotone3)" ; // attributes 2 , 6


// AUTHORITY
// ---------
// the trusted authority creates the public and the master keys
PK , MK := Setup( U ) ;

ConvertPOLICY( POLICY , ATTRIBUTES ) ;

TREE := [] ;
for i in [1..#POLICY] do
  TREE[i] := POLICY2TREE( POLICY[i] , ATTRIBUTES ) ;  
end for ;

TREE ;

// the trusted authority creates the decryption keys
D := [] ;
for i in [1..#POLICY] do
  D[i] := KeyGeneration( TREE[i] , MK ) ;
end for ;


// ENCRYPTOR
// ---------
// Suppose the HEADQUARTER wants to broadcast a message
// Then he encrypts it with attributes:
// 1, 2, 4, 5, 6
M := Random(K2) ; // the plaintext is a random element of F_2^q
GAMMA := { 1, 2, 4, 5, 6 } ;
c := Encryption( M, GAMMA, PK) ;


// DECRYPTOR
// ---------
// At first everyone can decrypt
M_ := Decryption( c , D[1] ) ;
M_ eq M ;
M_ := Decryption( c , D[2] ) ;
M_ eq M ;
M_ := Decryption( c , D[3] ) ;
M_ eq M ;

// Now suppose that the key of Plotone1 of AVIAZIONE has been stolen
// The HEADQUARTER than encrypts the next message
// without attribute 4 ( corresponding to Plotone1)

// ENCRYPTOR
// ---------
// Suppose the HEADQUARTER wants to broadcast a message
M := Random(K2) ; // the plaintext is a random element of F_2^q
GAMMA := { 1, 2, 5, 6 } ;
c := Encryption( M, GAMMA, PK) ;


// DECRYPTOR
// ---------
// Now, the decryption D[2] is not useful anymore
M_ := Decryption( c , D[1] ) ;
M_ eq M ;
M_ := Decryption( c , D[2] ) ;
M_ eq M ;
M_ := Decryption( c , D[3] ) ;
M_ eq M ;
