clear ;
/*
REF: "Attribute-based Encryption for Fine-Grained Access Control of Encrypted Data"
     Goyal, Pandey, Sahai, Waters
     Section 4.2 


NOTATION:
---------
  G_1 <--> <P>
  g   <--> P
  G_2 <--> F_q^2
  p   <--> r

*/

//////////////////////////////////////////////////////////////////////////////

// GLOBAL VARIABLES
// ----------------


// to generate a new curve uncomment the following line
load "pairing.m" ;

// to use known global parameter uncomment the following  lines

/*
K := GF(340282366920938463463374607431768216923) ;
E := EllipticCurve( [ K | 1, 0 ] ) ; 
K2<z> := ExtensionField< K , x | x^2+1 > ;
E2 := ChangeRing(E,K2) ;
P := E![199271605215943908268709599389110266979,225490490528012404940003766658466280865,1] ; 
r := Order(P) ;
*/

//////////////////////////////////////////////////////////////////////////////

// ATTENTION: 
// Library must be loaded after global variables are set.

load "kpabe_lib.m" ;


ATTRIBUTES := [
              "Stagione1",
              "Stagione2",
              "Stagione3",
              "Stagione4",
              "Stagione5",
              "Episodio1",
              "Episodio2",
              "Episodio3",
              "Episodio4",
              "Episodio5",
              "Episodio6",
              "Episodio7",
              "Episodio8",
              "Episodio9",
              "Episodio10",
              "Serie1",
              "Serie2",
              "Serie3"
              ] ;


n := #ATTRIBUTES ; // number of attributes
U := [i : i in [1..n]] ; // Universe of attributes

//POLICY := ">1(>5(Serie1,Stagione1,Episodio1,Episodio2,Episodio3),>5(Serie2,Stagione1,Episodio1,Episodio2,Episodio3))" ;
//POLICY := ">2(Stagione1,Stagione2)" ;
//POLICY := ">1(Stagione1,Stagione2)" ;
POLICY := "Stagione2" ;

// AUTHORITY
// ---------
PK , MK := Setup( U ) ;

ConvertPOLICY( POLICY , ATTRIBUTES ) ;

TREE := POLICY2TREE( POLICY , ATTRIBUTES ) ;
TREE ;

D := KeyGeneration( TREE, MK ) ;

// ENCRYPTOR
// ---------
M := Random(K2) ; // the plaintext is a random element of F_2^q
GAMMA := { 2, 3, 4 } ;
c := Encryption( M, GAMMA, PK) ;


// DECRYPTOR
// ---------
//DecryptNode(c,D,1) ;
M_ := Decryption( c , D ) ;

M_ eq M ;

